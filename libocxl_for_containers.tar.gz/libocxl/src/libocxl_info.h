const char *libocxl_info =
    "LibOCXL Version: 1.2.1\n"
    "CC: gcc\n"
    "Compiler Version: gcc (Ubuntu 9.3.0-10ubuntu2) 9.3.0\n"
    "CFLAGS: -g -Wall -Wextra -O2 -m64 -std=c11 -DLIBOCXL_SUPPRESS_INACCESSIBLE_WARNINGS -I src/include -I kernel/include -fPIC -D_FILE_OFFSET_BITS=64\n"
    "Git hash: 0533547764cfb7c70554afa8b3f56fee8690dd2c\n"
    "Build platform: Linux 5.4.0-37-generic #41-Ubuntu SMP Wed Jun 3 17:54:26 UTC 2020 ppc64le ppc64le ppc64le GNU/Linux\n";
