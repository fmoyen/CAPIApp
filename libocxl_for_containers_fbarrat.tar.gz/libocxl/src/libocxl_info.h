const char *libocxl_info =
    "LibOCXL Version: 1.1.0\n"
    "CC: gcc\n"
    "Compiler Version: gcc (Ubuntu 7.5.0-3ubuntu1~18.04) 7.5.0\n"
    "CFLAGS: -g -Wall -Wextra -O2 -m64 -std=c11 -DLIBOCXL_SUPPRESS_INACCESSIBLE_WARNINGS -I src/include -I kernel/include -fPIC -D_FILE_OFFSET_BITS=64\n"
    "Git hash: acca9d9e59572ebc9477ac5338c1656e307dd2b7-dirty\n"
    "Build platform: Linux 4.15.0-117-generic #118-Ubuntu SMP Fri Sep 4 19:59:20 UTC 2020 ppc64le ppc64le ppc64le GNU/Linux\n";
